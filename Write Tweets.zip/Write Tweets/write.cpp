#include <iostream>
#include <fstream>
#include<string>
using namespace std;

int main()
{
    ofstream Twitter("Twitter.txt", std::ios_base::app);

    char User_ID[20], Tweets[2000], Time[20], Date[20];

    cout << "Enter Your Id and tweet with data and time" << endl;
    cout << "Enter User ID: ";
    gets(User_ID);
    Twitter <<"User ID :"<< User_ID << endl;
    cout << "Enter Your Tweet::\n\t";
    gets(Tweets);
    Twitter <<"Tweet :"<< Tweets << endl;
    cout << "Enter Time Like hh:mm:sec :: ";
    gets(Time);
    Twitter <<"Time :" <<Time << endl;
    cout << "Enter Date Like dd/mm/yy :: ";
    gets(Date);
    Twitter <<"Date :" << Date << endl;

    Twitter.close();

    /*ifstream Twitters;
    string word;
    int count = 0;
    Twitters.open("Twitter.txt");

    while(!Twitters.eof())
    {
        Twitters >> word;
        count++;
    }

    T*/


    return 0;
}
